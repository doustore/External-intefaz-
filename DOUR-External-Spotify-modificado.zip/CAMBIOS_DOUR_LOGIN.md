# Cambios DOUR / External Spotify

- Se sustituyó la marca visual anterior por DOUR.
- El encabezado del acceso ahora muestra EXTERNAL SPOTIFY / External Spotify.
- El campo de key conserva `123` como valor inicial y muestra «Ingrese su key» como placeholder cuando está vacío.
- El botón principal ahora dice «Continuar» y usa un estilo rectangular redondeado con degradado violeta-azul.
- Se reemplazó el enlace de contacto por https://t.me/Jxsuesinho.
- Se ajustó el contenedor del video de introducción para ocupar toda el área disponible y recortar el video a pantalla completa.

La key `123` sigue pasando por la validación HTTPS configurada en `PantherAPIBaseURL`. Este cambio no agrega una clave maestra ni un bypass local: `123` debe existir y estar habilitada en el backend para permitir el acceso.

No se modificaron el motor de patches ni los componentes de explotación. Este entorno no dispone de Xcode/macOS, así que el proyecto Swift no se pudo compilar ni probar en un dispositivo iOS aquí.
